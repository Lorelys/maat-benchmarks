# Light update for the public maat-benchmarks repo

This update changes wording in four files. **No numbers change and no tests need to be re-run.** It makes the repo describe how the v1 results were actually scored, and it removes three statements that the saved runs contradict.

| File | Change |
|---|---|
| `README.md` | Adds a scoring note under the results table: how halted runs were scored, that some halts stopped correct output, so the "Maat on" means are upper bounds, and that a re-run is in progress. Corrects the revenue bullet from "detected 100%" to "flagged as a warning". |
| `results/WORKSTREAM_B_CONSOLIDATED.md` | Removes "zero false positives" for insurance and adds a one-line scoring note. |
| `CAUGHT_SCENARIOS.md` | Replaces "False positives in Maat arms: none". Notes that B2B and hospital halt rates include halts on correct output. |
| `GATE_RESULTS_SPEC.md` | Removes "intervene beats off" for insurance and notes the payout-key issue. |

## How to apply

1. In GitHub Desktop, open the maat-benchmarks repo, then **Repository → Show in Finder**.
2. Copy the four files from this `maat-benchmarks/` folder over the ones in your repo, keeping the same folder paths.
3. Back in GitHub Desktop, check the four diffs, commit ("Clarify v1 halt scoring; re-run in progress") and push.
